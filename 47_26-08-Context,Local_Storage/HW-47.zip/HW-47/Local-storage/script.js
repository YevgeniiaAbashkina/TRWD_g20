/* localStorage.setItem("myKey", [1, 2, 3, 4, 5, 6]);
console.log(localStorage.getItem("myKey"));
localStorage.clear();

const user = {
    name: "vasya",
    age: 32,
}

localStorage.setItem("user", JSON.stringify(user))

const user2 = JSON.parse(localStorage.getItem("user"))
console.log(user2)

const users = [user, user, user];
console.log(users)

localStorage.setItem("users", JSON.stringify(users)) */
