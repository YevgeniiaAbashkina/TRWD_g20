//Task01
//function getShortNames(arrName)     (["Kolya", "Anna", "Misha", "Mark", "Innokentiy"] -> ["Anna", "Mark"]) (length ==4)
//functin getShortNames(namesArray, nameLength) формирует массив из имен заданного к-ва букв
const arrayWithNames = ["Kolya", "Anna", "Misha", "Mark", "Innokentiy", "Jens"];

function getShortNames(array) {
    const resultsArr = array.filter(name => name.length == 4);
    return resultsArr;
}
console.log(getShortNames(arrayWithNames));
/////////////////////////////////////////////////
const arrayWithNames1 = ["Kolya", "Anna", "Misha", "Mark", "Innokentiy", "Jens"];

function getShortNames1(namesArray, nameLength) {
    const resultsArr = namesArray.filter(name => name.length == nameLength);
    return resultsArr;
}
console.log(getShortNames1(arrayWithNames1, 10));
//Task02
/* метод массив делителей этого числа
function getDevisors(12) -> [2,3,4,6]
function getDevisors(15) -> [3,5
function getDevisors(13) -> "13 is primy" */
function getDevisors(n) {
    let arrDevisors = [];
    
    for (let i = 1; i <= n; i++) {
        let result = n / i;
        if (n % i == 0) {
            if (result == 1 || result == n) {
                console.log("Number is symple");
            } else {
                arrDevisors.push(i);
            }
        }
    }
    return arrDevisors
}

console.log(getDevisors(12))
//Task03*
/* 
function sumDigitalNumber(100002345671) -> 1+0+0+0+0+2+3+4+5+6+7=(29) 2+9=(11) 1+1=(2) (recursion)
*/
sumDigitalNumber(100002345671);
function sumDigitalNumber(number) {
    const arrayOfCharacters = number.toString().split('');
    let sumOfDigits = 0;
    for (char of arrayOfCharacters) {
        let digit = Number(char)
        sumOfDigits += digit;
    }

    if (sumOfDigits.toString().split('').length > 1) {
        console.log(sumOfDigits);
        sumDigitalNumber(sumOfDigits);
    } else {
        console.log(sumOfDigits);
        return sumOfDigits;
    }
}