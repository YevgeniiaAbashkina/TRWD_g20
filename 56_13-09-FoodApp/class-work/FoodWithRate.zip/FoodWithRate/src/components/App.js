import '../css/App.css';
//import Main from './Main';
import Main from './MainFunk';

function App() {
  return (
    <div className="App">
      <Main/>
    </div>
  );
}

export default App;
