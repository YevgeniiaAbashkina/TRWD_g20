export default function Title(){
    return(
        <h1>The most important publications of today.</h1>
    )
}