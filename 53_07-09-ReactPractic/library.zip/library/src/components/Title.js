export default function Title(){
    return(
        <h1>Library</h1>
    )
}