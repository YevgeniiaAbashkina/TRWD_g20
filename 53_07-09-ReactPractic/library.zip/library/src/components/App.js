import '../css/App.css';
import Section from './MainSection';
import Title from './Title';

function App() {
  return (
    <div className="App">
      <Title/>
      <Section/>
    </div>
  );
}

export default App;
