//Task 01
/* 
"ffghhf fh fhhfhf" -> вернуть длинну самого короткого слова в строке (fh)=2
*/
function findShortestWord(string) {
  let shortest = 20;
  let array = string.split(" ");
    for (let i = 0; i <= array.length-1; i++) {
    if (array[i].length < shortest) {
        shortest = array[i].length;
    }
  }
  return shortest;
} 

console.log(findShortestWord("Ein Fahrradfahrer ist in Berlin-Prenzlauer Berg von einem Auto angefahren und dabei schwer verletzt worden"));
//Task 02
/* на вход приходит строка,  задача проверить, есть ли повторяющиеся символы, если нет то тру
function isIsogram("abcd") -> true
function isIsogram("abcdcb") -> false
function isIsogram("abcdA") -> false
*/
function isIsogram(string) {
    string = string.replaceAll(" ", "");
    let array = string.toLowerCase().split("");
    for (let i = 0; i < array.length; i++){
        for (let j = 0; j < array.length; j++){
                if (array[j] == array[i]) {
                    return false;
                } 
        }
        
    }
    return true;
}
console.log(isIsogram("Eise"));
//////////////////////////////////////////////////////

function isIsogram2(str) {
    str = str.toLowerCase();
    for (let i=0; i<str.length; i++) {
      if ( str.indexOf(str[i]) !== str.lastIndexOf(str[i]) ) {
        return false; 
      }
    }
  return true;
} 


console.log(isIsogram2("ise"));
