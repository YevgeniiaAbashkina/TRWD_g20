// Task01

let a = prompt("Первое число?", 1);
let b = prompt("Второе число?", 2);

alert(+a + +b);

// Task02

let workPerHour = prompt("Укажите стоимость Вашей работы за час!");
let workInDay = prompt("Сколько часов в день Вы работаете?");
const SUM_DAY = 22;

alert("Ваша заработная плата составляет:" + workPerHour * workInDay * SUM_DAY);

// Task03

let r = prompt("Enter your radius, please!" + " (cm)");
const PI = 3.14;
alert(PI * r ** 2 + ", cm");
