const styleBtn={
    margin:"50px auto",
    border:"none",
    background: "limegreen",
    padding: "10px",
    borderRadius:"10px",
    
}


export default function Button(){
    return(
    <button style={styleBtn}>Click me!</button>
    );
}