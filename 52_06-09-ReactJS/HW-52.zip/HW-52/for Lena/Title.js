export default function Title(){
    return(
    <h1 id="title" style={{color:"limegreen", text:"center"}}>Welcome to my home work!</h1>
    );
}