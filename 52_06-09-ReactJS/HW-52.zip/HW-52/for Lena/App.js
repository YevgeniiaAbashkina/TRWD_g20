import './App.css';
import Button from './Button';
import Title from './Title';
import Text from './Text';

export default function App() {
  return (
    <div className="container">
      <Title />
      <Text />
      <Button />
    </div>

  );
}

