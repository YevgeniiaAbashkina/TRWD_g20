const Albums=()=>{
    return(
        <div className="container">
            <h1 className="text-center my-5">All our albums</h1>
        </div>
    )
}

export default Albums;