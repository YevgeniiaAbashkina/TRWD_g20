const Loader=()=>{
    return(
        <div className="d-flex justify-content-center" style={{marginTop:"50px"}}>
            <div class="spinner-grow text-primary me-2" role="status"></div>
            <div class="spinner-grow text-primary me-2" role="status"></div>
            <div class="spinner-grow text-primary me-2" role="status"></div>
        </div>
    )
}

export default Loader;