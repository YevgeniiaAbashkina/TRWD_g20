const Type={
    addBook: "Books/ add book to books",
    getAllBooks: "Books/ get books trom local storage",
    addComment: "Books/ add comment to book"
}

export default Type;