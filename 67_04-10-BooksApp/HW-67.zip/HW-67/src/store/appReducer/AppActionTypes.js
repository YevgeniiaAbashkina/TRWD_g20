const Type={
    showLoader: "App/ start loading",
    hideLoader: "App/ stop loading"
}

export default Type;