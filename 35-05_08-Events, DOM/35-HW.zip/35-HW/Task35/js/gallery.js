//Task02
//Галерея    

let imgDiv = document.querySelector(".img");

const elements = Array.from(imgDiv);
console.log(typeof elements)//object :(

/*
imgDiv.forEach(img, index) => {
style.display = "none";
}
*/
