//=====Task01=====
let num1, num2;

num1 = +prompt("Enter first number");
num2 = +prompt("Enter second number");

let sum = num1 + num2;

// operator if:
if (sum < 10) {
    alert("Your sum so little!")
} else if (sum > 10) {
    alert("Your sum so big!")
}
else {
    alert("Bingo!")
}

// ?:
let message =   (sum < 10) ? "Your sum so little!" :
                (sum > 10) ? "Your sum so big!" : "Bingo!";
console.log(message);

//=====Task02=====
let login;

login = prompt("Enter your login");

// operator if:
if (login === "employee") {
    alert("Hi, employee!");
} else if (login === "boss") {
    alert("Hello, boss!");
} else if (login === "") {
    alert("no login...");
} else {
    alert("Hi, user!");
}

//switch:
switch (login) {
    case "employee":
        alert("Hi, employee!");
        break;
    case "boss":
        alert("Hello, boss!");
        break;
    case "":
        alert("no login...");
        break;
    default:
        alert("Hi, user!");
}

//=====Task03=====
let age;
age = +prompt("Enter your age!");

/* if (age >= 14 && age <= 90) {
    alert("your age is between 14 and 90");
} else if (!(age >= 14 && age <= 90)) {
    alert("your age is not between 14 and 90");
} */

let myCondition = (age >= 14 && age <= 90);
if (myCondition) {
    alert("your age is between 14 and 90");
} else if (!myCondition) {
    alert("your age is not between 14 and 90");
}



