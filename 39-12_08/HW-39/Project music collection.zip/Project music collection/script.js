const jazzBtn = document.querySelector("#jazz-btn"),
    rockBtn = document.querySelector("#rock-btn"),
    bluesBtn = document.querySelector("#blues-btn"),
    content = document.querySelector(".content");

    const div = document.createElement("div")

jazzBtn.onclick = () => {
    content.innerHTML = "";
    getItem(9, "Jazz");    
}

rockBtn.onclick = () => {
    content.innerHTML = "";
    getItem(5, "Rock");    
}

bluesBtn.onclick = () => {
    content.innerHTML = "";
    getItem(8, "Blues");    
}


function getColor() {
    return `${Math.random() * 256}, ${Math.random() * 256},  ${Math.random() * 256}`;
}


function getItem(n, text) {
    for (let i = 1; i <= n; i++){
        const div = document.createElement("div");
        div.className = "item"
        div.innerHTML = `<p>${text}-item</p>`
        div.style.backgroundColor = `rgb(${getColor()})`
        content.append(div)
    }
}
