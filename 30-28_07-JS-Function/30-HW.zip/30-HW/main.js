//Task01
/* n=10
function recursionOutput(n) -> "12345678910"
*/

function recursionOutput(n) {
    return n ? recursionOutput(n - 1) + n.toString(): "";
}

console.log(recursionOutput(7))

//Task02
/*  шалаш abba потоп наган "а роза упала на лапу азора"
function chekPolindrom("nagan") -> true;
        chekPolindrom("fgfr") -> false;
*/

function chekPalindrome(str) {
    return str.toLowerCase() === str.toLowerCase().split('').reverse().join('');
}

console.log(chekPalindrome("шалаш"));//"а роза упала на лапу азора" не работает, 

//Task03
//метод, который на основе массива вида users возвращает  массив вида changedUser

/*  const users =[
    {firstName: "Vasya", LastName: "Pupkin", id:1},
    {firstName: "Olya", LastName: "Pupk", id:2},
    {firstName: "Dima", LastName: "Pupok", id:3}
]
 changedUser ->[
    {fullName: Vasya Pupkin, id:1},
    {fullName: Olya Pupk, id:2},
    {fullName: Dima Pupok, id:3}full*/

const users = [
    { firstName: "Vasya", lastName: "Pupkin", id: 1 },
    { firstName: "Olya", lastName: "Pupka", id: 2 },
    { firstName: "Dima", lastName: "Pupok", id: 3 }
];

console.log(restructObject(users));

function restructObject(sourceArrayOfObject) {
    const changedUsers = [{}];

    for (let key of sourceArrayOfObject) {
        changedUsers.push({
            fullName: key.firstName + " " + key.lastName,
            id: key.id
        })
    }
    return changedUsers;
}



