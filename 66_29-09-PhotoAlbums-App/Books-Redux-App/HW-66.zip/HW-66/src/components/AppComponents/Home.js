const Home = ()=>{
    return(
        <div className = 'container-fluid' style = {{backgroundImage: 'url(https://www.ukrgate.com/eng/wp-content/uploads/2021/02/The-Ukrainian-Book-Institute-Purchases-380.9-Thousand-Books-for-Public-Libraries1.jpeg)', height: '100vh', backgroundRepeat:'none', backgroundSize: 'cover', paddingTop: '100px'}}>
            <h4 className = 'text-center my-4 text-dark w-50 mx-auto p-2 display-1' style ={{fontSize: '40px', textTransform:"uppercase"}}>Wellcome <br/> to the best APP for learning <span style ={{fontWeight: '800'}}><br/>Fullstack development!</span> </h4>
        </div>
    )
}

export default Home;
