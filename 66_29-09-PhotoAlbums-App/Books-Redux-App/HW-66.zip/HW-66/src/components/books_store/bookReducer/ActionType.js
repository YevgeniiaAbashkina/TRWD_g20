const ActionType={
    initState: "Books/ state initials from local storage",
    addBook: "Book/ add new book",

}

export default ActionType;