const AppActionType={
    showLoader: "App/ show loader",
    hideLoader: "App/ hide loader"
}

export default AppActionType;