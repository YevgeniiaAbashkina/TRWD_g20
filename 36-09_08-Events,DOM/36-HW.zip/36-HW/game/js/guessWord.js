const input = document.querySelector("#userAnswer"),
    submitBtn = document.querySelector("#button"),
    checkBtn = document.querySelector("#checkBtn");

hide(checkBtn)

function changeMessage(message) {
    document.querySelector("#message").innerHTML = message;
}

function hide(element) {
    element.style.display = "none"
}

function show(element) {
    element.style.display = "block"
}


submitBtn.onclick = () => {
    let guesWord = input.value.toLowerCase().split("");
    const numLetter = guesWord.length;
    hide(submitBtn)
    changeMessage(`Your word is ${numLetter} letters`);
    /* guesWord.forEach(element => element[i] == "-");
    input.innerHTML=guesWord */
    show(checkBtn)
    
}


